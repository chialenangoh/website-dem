import EcommerceApp from "@/components/ecommerce-app"

export default function Home() {
  return <EcommerceApp />
}
