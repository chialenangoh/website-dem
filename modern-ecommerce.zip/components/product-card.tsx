"use client"

import type React from "react"

import { useContext } from "react"
import Image from "next/image"
import { Star, ShoppingCart, Heart } from "lucide-react"
import { EcommerceContext } from "./ecommerce-app"

interface Product {
  id: number
  name: string
  category: string
  price: number
  image: string
  rating: number
  reviews: number
  stock: number
  description: string
}

interface ProductCardProps {
  product: Product
}

export default function ProductCard({ product }: ProductCardProps) {
  const { setCurrentView, setSelectedProduct, cart, setCart, wishlist, setWishlist } = useContext(EcommerceContext)

  const addToCart = (e: React.MouseEvent) => {
    e.stopPropagation()
    const existingItem = cart.find((item: any) => item.id === product.id)
    if (existingItem) {
      setCart(cart.map((item: any) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)))
    } else {
      setCart([...cart, { ...product, quantity: 1 }])
    }
  }

  const toggleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation()
    const isInWishlist = wishlist.some((item: any) => item.id === product.id)
    if (isInWishlist) {
      setWishlist(wishlist.filter((item: any) => item.id !== product.id))
    } else {
      setWishlist([...wishlist, product])
    }
  }

  const viewProduct = () => {
    setSelectedProduct(product)
    setCurrentView("product")
  }

  const isInWishlist = wishlist.some((item: any) => item.id === product.id)

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group">
      <div className="relative" onClick={viewProduct}>
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          width={400}
          height={300}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <button
          onClick={toggleWishlist}
          className={`absolute top-2 right-2 p-2 rounded-full ${
            isInWishlist ? "bg-red-500 text-white" : "bg-white text-gray-600"
          } hover:bg-red-500 hover:text-white transition-colors`}
        >
          <Heart className="w-4 h-4" />
        </button>
      </div>

      <div className="p-4">
        <h3 className="font-semibold text-lg mb-2 line-clamp-2" onClick={viewProduct}>
          {product.name}
        </h3>
        <div className="flex items-center mb-2">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-gray-600 ml-2">({product.reviews})</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-blue-600">${product.price}</span>
          <button
            onClick={addToCart}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-1"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Add to Cart</span>
          </button>
        </div>
      </div>
    </div>
  )
}
