"use client"

import { useContext, useState } from "react"
import { Star, ShoppingCart, Heart, Plus, Minus } from "lucide-react"
import { EcommerceContext } from "./ecommerce-app"
import ImageGallery from "./image-gallery"

export default function ProductDetailPage() {
  const { selectedProduct, cart, setCart } = useContext(EcommerceContext)
  const [quantity, setQuantity] = useState(1)

  const addToCart = () => {
    const existingItem = cart.find((item: any) => item.id === selectedProduct.id)
    if (existingItem) {
      setCart(
        cart.map((item: any) =>
          item.id === selectedProduct.id ? { ...item, quantity: item.quantity + quantity } : item,
        ),
      )
    } else {
      setCart([...cart, { ...selectedProduct, quantity }])
    }
  }

  if (!selectedProduct) return <div>Product not found</div>

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-4">
          <ImageGallery images={[selectedProduct.image]} productName={selectedProduct.name} />
        </div>

        {/* Rest of the component remains the same */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold mb-2">{selectedProduct.name}</h1>
            <div className="flex items-center space-x-4 mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(selectedProduct.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="text-gray-600">({selectedProduct.reviews} reviews)</span>
            </div>
            <p className="text-4xl font-bold text-blue-600 mb-4">${selectedProduct.price}</p>
            <p className="text-gray-700 mb-6">{selectedProduct.description}</p>
          </div>

          <div className="flex items-center space-x-4 mb-6">
            <label className="font-medium">Quantity:</label>
            <div className="flex items-center border border-gray-300 rounded-lg">
              <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="p-2 hover:bg-gray-100">
                <Minus className="w-4 h-4" />
              </button>
              <span className="px-4 py-2 border-x">{quantity}</span>
              <button onClick={() => setQuantity(quantity + 1)} className="p-2 hover:bg-gray-100">
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex space-x-4">
            <button
              onClick={addToCart}
              className="flex-1 bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
            >
              <ShoppingCart className="w-5 h-5" />
              <span>Add to Cart</span>
            </button>
            <button className="px-6 py-3 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
              <Heart className="w-5 h-5" />
            </button>
          </div>

          <div className="border-t pt-6">
            <h3 className="font-semibold mb-2">Product Details</h3>
            <ul className="space-y-1 text-gray-600">
              <li>• Stock: {selectedProduct.stock} units available</li>
              <li>• Category: {selectedProduct.category}</li>
              <li>• Free shipping on orders over $500</li>
              <li>• 30-day return policy</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6">Customer Reviews</h2>
        <div className="space-y-6">
          {[1, 2, 3].map((review) => (
            <div key={review} className="bg-white p-6 rounded-lg shadow">
              <div className="flex items-center space-x-4 mb-4">
                <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                  <span className="text-gray-600 font-semibold">U{review}</span>
                </div>
                <div>
                  <h4 className="font-semibold">Customer {review}</h4>
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-700">Great product! Highly recommend to anyone looking for quality and value.</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
