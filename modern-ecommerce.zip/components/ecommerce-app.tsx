"use client"

import { useState, createContext } from "react"
import Header from "./header"
import HomePage from "./home-page"
import ProductsPage from "./products-page"
import ProductDetailPage from "./product-detail-page"
import CartPage from "./cart-page"
import CheckoutPage from "./checkout-page"
import ProfilePage from "./profile-page"
import LoginPage from "./login-page"
import AdminDashboard from "./admin-dashboard"
import Footer from "./footer"

// Context for global state management
export const EcommerceContext = createContext<any>(null)

// Mock data
export const mockProducts = [
  {
    id: 1,
    name: "MacBook Pro M3",
    category: "electronics",
    price: 1999,
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&h=400&fit=crop&crop=center",
    rating: 4.8,
    reviews: 245,
    stock: 15,
    description: "Latest MacBook Pro with M3 chip, 16GB RAM, 512GB SSD",
  },
  {
    id: 2,
    name: "iPhone 15 Pro",
    category: "electronics",
    price: 999,
    image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop&crop=center",
    rating: 4.7,
    reviews: 189,
    stock: 25,
    description: "iPhone 15 Pro with titanium design and advanced camera system",
  },
  {
    id: 3,
    name: "Designer Jacket",
    category: "clothing",
    price: 299,
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=400&fit=crop&crop=center",
    rating: 4.5,
    reviews: 87,
    stock: 8,
    description: "Premium leather jacket with modern design",
  },
  {
    id: 4,
    name: 'Smart TV 55"',
    category: "electronics",
    price: 799,
    image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=400&fit=crop&crop=center",
    rating: 4.6,
    reviews: 156,
    stock: 12,
    description: "4K Ultra HD Smart TV with HDR and built-in streaming",
  },
  {
    id: 5,
    name: "Luxury Sofa",
    category: "home",
    price: 1299,
    image: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400&h=400&fit=crop&crop=center",
    rating: 4.9,
    reviews: 93,
    stock: 5,
    description: "Comfortable 3-seater sofa with premium fabric",
  },
  {
    id: 6,
    name: "Running Shoes",
    category: "clothing",
    price: 159,
    image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400&h=400&fit=crop&crop=center",
    rating: 4.4,
    reviews: 203,
    stock: 30,
    description: "Professional running shoes with advanced cushioning",
  },
  {
    id: 7,
    name: "Wireless Headphones",
    category: "electronics",
    price: 249,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop&crop=center",
    rating: 4.6,
    reviews: 178,
    stock: 20,
    description: "Premium noise-cancelling wireless headphones",
  },
  {
    id: 8,
    name: "Coffee Table",
    category: "home",
    price: 399,
    image: "https://images.unsplash.com/photo-1506439773649-6e0eb8cfb237?w=400&h=400&fit=crop&crop=center",
    rating: 4.3,
    reviews: 64,
    stock: 7,
    description: "Modern minimalist coffee table with storage",
  },
  {
    id: 9,
    name: "Winter Coat",
    category: "clothing",
    price: 189,
    image: "https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=400&h=400&fit=crop&crop=center",
    rating: 4.7,
    reviews: 142,
    stock: 12,
    description: "Warm winter coat with premium insulation",
  },
  {
    id: 10,
    name: "Gaming Mouse",
    category: "electronics",
    price: 79,
    image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400&h=400&fit=crop&crop=center",
    rating: 4.4,
    reviews: 298,
    stock: 45,
    description: "High-precision gaming mouse with RGB lighting",
  },
  {
    id: 11,
    name: "Table Lamp",
    category: "home",
    price: 89,
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=400&h=400&fit=crop&crop=center",
    rating: 4.2,
    reviews: 76,
    stock: 18,
    description: "Modern LED table lamp with adjustable brightness",
  },
  {
    id: 12,
    name: "Denim Jeans",
    category: "clothing",
    price: 99,
    image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=400&h=400&fit=crop&crop=center",
    rating: 4.5,
    reviews: 167,
    stock: 28,
    description: "Classic fit denim jeans with premium fabric",
  },
  {
    id: 13,
    name: "Wireless Speaker",
    category: "electronics",
    price: 129,
    image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=400&fit=crop&crop=center",
    rating: 4.3,
    reviews: 134,
    stock: 22,
    description: "Portable Bluetooth speaker with rich sound quality",
  },
  {
    id: 14,
    name: "Desk Chair",
    category: "home",
    price: 299,
    image: "https://images.unsplash.com/photo-1581539250439-c96689b516dd?w=400&h=400&fit=crop&crop=center",
    rating: 4.6,
    reviews: 89,
    stock: 11,
    description: "Ergonomic office chair with lumbar support",
  },
  {
    id: 15,
    name: "Sneakers",
    category: "clothing",
    price: 119,
    image: "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=400&h=400&fit=crop&crop=center",
    rating: 4.4,
    reviews: 221,
    stock: 35,
    description: "Comfortable everyday sneakers for casual wear",
  },
  {
    id: 16,
    name: "Smart Watch",
    category: "electronics",
    price: 399,
    image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop&crop=center",
    rating: 4.7,
    reviews: 167,
    stock: 18,
    description: "Advanced fitness tracking smartwatch with GPS",
  },
  {
    id: 17,
    name: "Throw Pillow",
    category: "home",
    price: 29,
    image: "https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?w=400&h=400&fit=crop&crop=center",
    rating: 4.2,
    reviews: 98,
    stock: 50,
    description: "Soft decorative throw pillow for living room",
  },
  {
    id: 18,
    name: "Hoodie",
    category: "clothing",
    price: 79,
    image: "https://images.unsplash.com/photo-1556821840-3a9fbc86b81b?w=400&h=400&fit=crop&crop=center",
    rating: 4.5,
    reviews: 156,
    stock: 25,
    description: "Comfortable cotton hoodie for casual wear",
  },
  {
    id: 19,
    name: "Gaming Keyboard",
    category: "electronics",
    price: 149,
    image: "https://images.unsplash.com/photo-1541140532154-b024d705b90a?w=400&h=400&fit=crop&crop=center",
    rating: 4.6,
    reviews: 203,
    stock: 30,
    description: "Mechanical gaming keyboard with RGB backlighting",
  },
  {
    id: 20,
    name: "Wall Art",
    category: "home",
    price: 59,
    image: "https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?w=400&h=400&fit=crop&crop=center",
    rating: 4.1,
    reviews: 67,
    stock: 15,
    description: "Modern abstract wall art for home decoration",
  },
  {
    id: 21,
    name: "Digital Camera",
    category: "electronics",
    price: 899,
    image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400&h=400&fit=crop&crop=center",
    rating: 4.8,
    reviews: 189,
    stock: 12,
    description: "Professional DSLR camera with 24MP sensor",
  },
  {
    id: 22,
    name: "Tablet",
    category: "electronics",
    price: 549,
    image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&h=400&fit=crop&crop=center",
    rating: 4.5,
    reviews: 267,
    stock: 20,
    description: "10.9-inch tablet with A14 Bionic chip",
  },
  {
    id: 23,
    name: "Gaming Console",
    category: "electronics",
    price: 499,
    image: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400&h=400&fit=crop&crop=center",
    rating: 4.9,
    reviews: 334,
    stock: 8,
    description: "Next-gen gaming console with 4K gaming",
  },
  {
    id: 24,
    name: "Drone",
    category: "electronics",
    price: 799,
    image: "https://images.unsplash.com/photo-1473968512647-3e447244af8f?w=400&h=400&fit=crop&crop=center",
    rating: 4.6,
    reviews: 145,
    stock: 15,
    description: "4K camera drone with GPS and obstacle avoidance",
  },
  {
    id: 25,
    name: "VR Headset",
    category: "electronics",
    price: 299,
    image: "https://images.unsplash.com/photo-1622979135225-d2ba269cf1ac?w=400&h=400&fit=crop&crop=center",
    rating: 4.4,
    reviews: 198,
    stock: 18,
    description: "Virtual reality headset with wireless connectivity",
  },
  {
    id: 26,
    name: "Smart Home Hub",
    category: "electronics",
    price: 99,
    image: "https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=400&h=400&fit=crop&crop=center",
    rating: 4.3,
    reviews: 156,
    stock: 25,
    description: "Voice-controlled smart home automation hub",
  },
  {
    id: 27,
    name: "Webcam",
    category: "electronics",
    price: 89,
    image: "https://images.unsplash.com/photo-1587825140708-dfaf72ae4b04?w=400&h=400&fit=crop&crop=center",
    rating: 4.2,
    reviews: 223,
    stock: 40,
    description: "1080p HD webcam with auto-focus and noise reduction",
  },
  {
    id: 28,
    name: "Power Bank",
    category: "electronics",
    price: 39,
    image: "https://images.unsplash.com/photo-1609592669390-e09a1fb0cac5?w=400&h=400&fit=crop&crop=center",
    rating: 4.1,
    reviews: 312,
    stock: 60,
    description: "20,000mAh portable charger with fast charging",
  },
  {
    id: 29,
    name: "Bluetooth Earbuds",
    category: "electronics",
    price: 179,
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&h=400&fit=crop&crop=center",
    rating: 4.7,
    reviews: 289,
    stock: 35,
    description: "True wireless earbuds with active noise cancellation",
  },
  {
    id: 30,
    name: "Fitness Smartwatch",
    category: "electronics",
    price: 249,
    image: "https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=400&h=400&fit=crop&crop=center",
    rating: 4.5,
    reviews: 201,
    stock: 22,
    description: "Fitness smartwatch with heart rate monitoring",
  },
]

export const mockUsers = [
  { id: 1, email: "john@example.com", name: "John Doe", role: "customer" },
  { id: 2, email: "admin@store.com", name: "Admin User", role: "admin" },
]

export const mockOrders = [
  {
    id: 1,
    userId: 1,
    items: [{ productId: 1, quantity: 1, price: 1999 }],
    total: 1999,
    status: "delivered",
    date: "2024-05-15",
  },
  {
    id: 2,
    userId: 1,
    items: [{ productId: 3, quantity: 2, price: 299 }],
    total: 598,
    status: "shipped",
    date: "2024-06-10",
  },
]

// Main App Component
export default function EcommerceApp() {
  const [currentView, setCurrentView] = useState("home")
  const [selectedProduct, setSelectedProduct] = useState(null)
  const [products, setProducts] = useState(mockProducts)
  const [users, setUsers] = useState(mockUsers)
  const [orders, setOrders] = useState(mockOrders)
  const [currentUser, setCurrentUser] = useState(null)
  const [cart, setCart] = useState([])
  const [wishlist, setWishlist] = useState([])
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [priceRange, setPriceRange] = useState([0, 5000])
  const [showMobileMenu, setShowMobileMenu] = useState(false)

  const contextValue = {
    currentView,
    setCurrentView,
    selectedProduct,
    setSelectedProduct,
    products,
    setProducts,
    users,
    setUsers,
    orders,
    setOrders,
    currentUser,
    setCurrentUser,
    cart,
    setCart,
    wishlist,
    setWishlist,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    priceRange,
    setPriceRange,
    showMobileMenu,
    setShowMobileMenu,
  }

  return (
    <EcommerceContext.Provider value={contextValue}>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main>
          {currentView === "home" && <HomePage />}
          {currentView === "products" && <ProductsPage />}
          {currentView === "product" && <ProductDetailPage />}
          {currentView === "cart" && <CartPage />}
          {currentView === "checkout" && <CheckoutPage />}
          {currentView === "profile" && <ProfilePage />}
          {currentView === "login" && <LoginPage />}
          {currentView === "admin" && <AdminDashboard />}
        </main>
        <Footer />
      </div>
    </EcommerceContext.Provider>
  )
}
