"use client"

import { useContext } from "react"
import { EcommerceContext } from "./ecommerce-app"

export default function ProfilePage() {
  const { currentUser, setCurrentUser, setCurrentView, orders } = useContext(EcommerceContext)

  const userOrders = orders.filter((order: any) => order.userId === currentUser?.id)

  const handleLogout = () => {
    setCurrentUser(null)
    setCurrentView("home")
  }

  if (!currentUser) {
    return <div>Please login to view your profile.</div>
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="bg-white rounded-lg shadow p-6 mb-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">My Profile</h1>
          <button onClick={handleLogout} className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700">
            Logout
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h2 className="text-lg font-semibold mb-4">Account Information</h2>
            <p>
              <strong>Name:</strong> {currentUser.name}
            </p>
            <p>
              <strong>Email:</strong> {currentUser.email}
            </p>
            <p>
              <strong>Role:</strong> {currentUser.role}
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h2 className="text-xl font-bold mb-6">Order History</h2>
        {userOrders.length === 0 ? (
          <p className="text-gray-600">No orders yet.</p>
        ) : (
          <div className="space-y-4">
            {userOrders.map((order: any) => (
              <div key={order.id} className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold">Order #{order.id}</span>
                  <span
                    className={`px-2 py-1 rounded text-sm ${
                      order.status === "delivered"
                        ? "bg-green-100 text-green-800"
                        : order.status === "shipped"
                          ? "bg-blue-100 text-blue-800"
                          : "bg-yellow-100 text-yellow-800"
                    }`}
                  >
                    {order.status}
                  </span>
                </div>
                <p className="text-gray-600">Date: {order.date}</p>
                <p className="font-semibold">Total: ${order.total}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
