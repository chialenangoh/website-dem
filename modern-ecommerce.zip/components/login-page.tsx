"use client"

import type React from "react"

import { useContext, useState } from "react"
import { EcommerceContext } from "./ecommerce-app"

export default function LoginPage() {
  const { setCurrentUser, setCurrentView, users } = useContext(EcommerceContext)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [isSignup, setIsSignup] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const user = users.find((u: any) => u.email === email)
    if (user || isSignup) {
      setCurrentUser(user || { id: Date.now(), email, name: "New User", role: "customer" })
      setCurrentView("home")
    } else {
      alert("User not found. Try admin@store.com for admin access.")
    }
  }

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="bg-white p-8 rounded-lg shadow">
        <h1 className="text-2xl font-bold mb-6 text-center">{isSignup ? "Sign Up" : "Login"}</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            required
          />
          <button
            type="submit"
            className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            {isSignup ? "Sign Up" : "Login"}
          </button>
        </form>
        <p className="text-center mt-4">
          {isSignup ? "Already have an account?" : "Don't have an account?"}
          <button onClick={() => setIsSignup(!isSignup)} className="text-blue-600 hover:text-blue-700 ml-1">
            {isSignup ? "Login" : "Sign Up"}
          </button>
        </p>
        <div className="mt-4 p-3 bg-gray-100 rounded text-sm">
          <p>
            <strong>Demo Accounts:</strong>
          </p>
          <p>Customer: john@example.com</p>
          <p>Admin: admin@store.com</p>
        </div>
      </div>
    </div>
  )
}
