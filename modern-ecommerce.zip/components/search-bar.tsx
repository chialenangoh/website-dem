"use client"

import type React from "react"

import { useContext } from "react"
import { Search } from "lucide-react"
import { EcommerceContext } from "./ecommerce-app"

export default function SearchBar() {
  const { searchQuery, setSearchQuery, setCurrentView } = useContext(EcommerceContext)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      setCurrentView("products")
    }
  }

  return (
    <form onSubmit={handleSearch} className="hidden sm:block">
      <div className="relative">
        <input
          type="text"
          placeholder="Search products..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <Search className="absolute left-3 top-2.5 w-5 h-5 text-gray-400" />
      </div>
    </form>
  )
}
