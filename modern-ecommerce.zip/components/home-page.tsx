"use client"

import { useContext } from "react"
import Image from "next/image"
import { EcommerceContext } from "./ecommerce-app"
import ProductCard from "./product-card"
import HeroBanner from "./hero-banner"
import Testimonials from "./testimonials"
import BrandShowcase from "./brand-showcase"

export default function HomePage() {
  const { setCurrentView, products } = useContext(EcommerceContext)
  const featuredProducts = products.slice(0, 4)

  return (
    <div>
      {/* Hero Section */}
      <HeroBanner />

      {/* Brand Showcase */}
      <BrandShowcase />

      {/* Categories Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Shop by Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Electronics",
                image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?w=600&h=400&fit=crop&crop=center",
                category: "electronics",
              },
              {
                name: "Fashion",
                image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&h=400&fit=crop&crop=center",
                category: "clothing",
              },
              {
                name: "Home & Living",
                image: "https://images.unsplash.com/photo-1484154218962-a197022b5858?w=600&h=400&fit=crop&crop=center",
                category: "home",
              },
            ].map((cat) => (
              <div key={cat.category} className="relative group cursor-pointer overflow-hidden rounded-lg shadow-lg">
                <Image
                  src={cat.image || "/placeholder.svg"}
                  alt={cat.name}
                  width={600}
                  height={400}
                  className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                  <h3 className="text-white text-2xl font-bold">{cat.name}</h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <Testimonials />
    </div>
  )
}
