"use client"

import { useContext } from "react"
import { ShoppingCart, User, Menu, X } from "lucide-react"
import { EcommerceContext } from "./ecommerce-app"
import SearchBar from "./search-bar"

export default function Header() {
  const { currentUser, setCurrentView, cart, showMobileMenu, setShowMobileMenu } = useContext(EcommerceContext)

  return (
    <header className="bg-white shadow-sm border-b sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <button
              onClick={() => setCurrentView("home")}
              className="text-2xl font-bold text-blue-600 hover:text-blue-700"
            >
              GLORIOUS SHOP
            </button>
          </div>

          <nav className="hidden md:flex space-x-8">
            <button onClick={() => setCurrentView("home")} className="text-gray-700 hover:text-blue-600">
              Home
            </button>
            <button onClick={() => setCurrentView("products")} className="text-gray-700 hover:text-blue-600">
              Products
            </button>
            <button className="text-gray-700 hover:text-blue-600">About</button>
            <button className="text-gray-700 hover:text-blue-600">Contact</button>
          </nav>

          <div className="flex items-center space-x-4">
            <SearchBar />

            <button onClick={() => setCurrentView("cart")} className="relative p-2 text-gray-600 hover:text-blue-600">
              <ShoppingCart className="w-6 h-6" />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {cart.reduce((sum: number, item: any) => sum + item.quantity, 0)}
                </span>
              )}
            </button>

            {currentUser ? (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setCurrentView("profile")}
                  className="flex items-center space-x-1 text-gray-700 hover:text-blue-600"
                >
                  <User className="w-5 h-5" />
                  <span className="hidden sm:inline">{currentUser.name}</span>
                </button>
                {currentUser.role === "admin" && (
                  <button
                    onClick={() => setCurrentView("admin")}
                    className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700"
                  >
                    Admin
                  </button>
                )}
              </div>
            ) : (
              <button
                onClick={() => setCurrentView("login")}
                className="flex items-center space-x-1 text-gray-700 hover:text-blue-600"
              >
                <User className="w-5 h-5" />
                <span className="hidden sm:inline">Login</span>
              </button>
            )}

            <button onClick={() => setShowMobileMenu(!showMobileMenu)} className="md:hidden p-2 text-gray-600">
              {showMobileMenu ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {showMobileMenu && (
        <div className="md:hidden border-t bg-white">
          <div className="px-4 py-2 space-y-2">
            <button
              onClick={() => {
                setCurrentView("home")
                setShowMobileMenu(false)
              }}
              className="block w-full text-left py-2 text-gray-700"
            >
              Home
            </button>
            <button
              onClick={() => {
                setCurrentView("products")
                setShowMobileMenu(false)
              }}
              className="block w-full text-left py-2 text-gray-700"
            >
              Products
            </button>
            <button className="block w-full text-left py-2 text-gray-700">About</button>
            <button className="block w-full text-left py-2 text-gray-700">Contact</button>
          </div>
        </div>
      )}
    </header>
  )
}
