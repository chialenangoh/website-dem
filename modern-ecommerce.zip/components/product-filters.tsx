"use client"

import { useContext } from "react"
import { Filter } from "lucide-react"
import { EcommerceContext } from "./ecommerce-app"

export default function ProductFilters() {
  const { selectedCategory, setSelectedCategory, priceRange, setPriceRange } = useContext(EcommerceContext)

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "electronics", label: "Electronics" },
    { value: "clothing", label: "Clothing" },
    { value: "home", label: "Home & Living" },
  ]

  return (
    <div className="w-full lg:w-64 space-y-6">
      <div className="bg-white p-6 rounded-lg shadow">
        <h3 className="font-semibold mb-4 flex items-center">
          <Filter className="w-5 h-5 mr-2" />
          Filters
        </h3>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Category</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {categories.map((cat) => (
                <option key={cat.value} value={cat.value}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">
              Price Range: ${priceRange[0]} - ${priceRange[1]}
            </label>
            <div className="space-y-2">
              <input
                type="range"
                min="0"
                max="5000"
                value={priceRange[0]}
                onChange={(e) => setPriceRange([Number.parseInt(e.target.value), priceRange[1]])}
                className="w-full"
              />
              <input
                type="range"
                min="0"
                max="5000"
                value={priceRange[1]}
                onChange={(e) => setPriceRange([priceRange[0], Number.parseInt(e.target.value)])}
                className="w-full"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
