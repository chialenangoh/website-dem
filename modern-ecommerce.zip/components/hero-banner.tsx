"use client"

import Image from "next/image"

export default function HeroBanner() {
  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-purple-700 text-white overflow-hidden">
      <div className="absolute inset-0 bg-black opacity-20"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Shop the Future Today</h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">Discover amazing products with unbeatable prices</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <button className="bg-white text-blue-600 px-8 py-3 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors">
                Shop Now
              </button>
              <button className="border-2 border-white text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors">
                Learn More
              </button>
            </div>
          </div>
          <div className="hidden lg:block">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <Image
                  src="https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=200&h=200&fit=crop&crop=center"
                  alt="Featured MacBook"
                  width={200}
                  height={200}
                  className="rounded-lg shadow-lg"
                />
                <Image
                  src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&h=150&fit=crop&crop=center"
                  alt="Featured Headphones"
                  width={200}
                  height={150}
                  className="rounded-lg shadow-lg"
                />
              </div>
              <div className="space-y-4 mt-8">
                <Image
                  src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&h=150&fit=crop&crop=center"
                  alt="Featured Smartwatch"
                  width={200}
                  height={150}
                  className="rounded-lg shadow-lg"
                />
                <Image
                  src="https://images.unsplash.com/photo-1549298916-b41d501d3772?w=200&h=200&fit=crop&crop=center"
                  alt="Featured Shoes"
                  width={200}
                  height={200}
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
